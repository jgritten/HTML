<!--
Date: November 20 2014
Name: Brett Howard
Abstract: Travel Experts main page pictures.
-->
<?php
?>
<!DOCTYPE html>
<html>
<body>
<div align="center">
<img src="images/pic1.jpg" height="230" width="310"><img src="images/pic2.jpg" height="230" width="310">
<img src="images/pic3.jpg" height="230" width="310"></br><img src="images/pic4.jpg" height="230" width="310">
<img src="images/pic5.jpg" height="230" width="310"><img src="images/pic6.jpg" height="230" width="310">
</div>
<hr>
</body>
</html>