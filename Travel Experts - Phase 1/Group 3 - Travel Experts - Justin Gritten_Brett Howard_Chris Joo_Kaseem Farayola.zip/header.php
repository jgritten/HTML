<!DOCTYPE html>
<html>
<head>
   <title><?php print($title); ?></title>
</head>
<body>
