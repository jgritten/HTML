<?php
$dbh = mysql_connect("localhost","root","") or die("cannot connect");
mysql_select_db("travelexperts");

$result = mysql_query("SELECT * FROM customers ORDER BY customerid DESC LIMIT 0, 1");
while ($row = mysql_fetch_row($result))
{
	$id = $row[0];
	echo $id;    	// Echos highest Customer ID. Use this for Credit Card CustomerID
}

?>