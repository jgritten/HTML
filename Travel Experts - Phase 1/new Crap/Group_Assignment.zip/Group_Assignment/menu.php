<html>
<head>
<title>Lan Gear</title>
</head>
<style>
l:hover {color:white; cursor:pointer;}
</style>
<div style="border:2px solid; background-color:#1DDCF5; height:130px; width:1000px;">
<div style="position:absolute; top:20px;">
<img src="logo.jpg" width="250">
</div>
<div style="color:white; position:absolute; font-size:20; width:400px; height:50px; top:10px; left:610px;">
<i><b><font face="arial">Quality Networking Hardware & Software</font></b></i>
</div>
<div style="color:white; position:absolute; background-color:#1DDCF5; font-size:20; width:570px; height:50px; top:70px; left:370px;">
<font face="arial">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp| <l>Home Page</l> | <l>Orders</l> | <l>Support</l> | <l>Registration</l> | <br> | <l>Routers</l> | <l>Switches</l> | <l>Adapters</l> | <l>Bridges</l> | <l>Servers</l> | <l>Software</l> | </font>
</div>
<body>
<div style="position:absolute; font-size:35; width:600px; height:50px; top:150px; left:10px;">
<font face="arial"><b>Technical Support Request Form</b></font>
</div>
<div style="position:absolute; Color:white; font-size:20; background-color:#1DDCF5; width:130px; height:150px; top:210px; left:10px;">
<b> &nbspContact<br>
 &nbspInformation</b>
</div>
<div style="position:absolute; color:white; font-size:20; background-color:#1DDCF5; width:130px; height:150px; top:370px; left:10px;">
<b>&nbsp System<br>
&nbsp Information</b>
</div>
<div style="position:absolute; color:white; font-size:20; background-color:#1DDCF5; width:130px; height:150px; top:530px; left:10px;">
<b> &nbspSupport<br>
 &nbspIssue</b>
</div>
<div style="border:1px solid black; position:absolute; font-size:18; width:1000px; height:160px; top:203px; left:5px;">
<div style="position:absolute; font-size:20; left:150px; top:12px;">
Your Name:<br>
Your Phone:<br>
Your E-mail address:<br>
<input type="checkbox"> Yes, I have a support contract<br>
Contract ID:
</div>
<div style="position:absolute; left:350px; top:12px;">
<input type="text" size=90 maxlength=90><br>
<input type="text" size=90 maxlength=90><br>
<input type="text" size=90 maxlength=90><br>
<br>
<input type="text" size=90 maxlength=90>
</div>
</div>
<div style="border:1px solid black; position:absolute; font-size:18; width:1000px; height:160px; top:364px; left:5px;">
<div style="position:absolute; font-size:20; left:150px; top:12px;">
Product:<br>
Your Operating System:<br>
System Memory:
<div style="position:absolute; left:200px; top:0px; font-size:20;">
<select style="width:150px;"><optgroup label="LanPass115"><option selected>LanPass115</option><option>LanPass2</option></select><br>
<select style="width:150px;"><optgroup label="Windows 98"><option selected>Windows 98</option><option>Windows Xp</option></select><br>
</div>
<div style="border:1px solid black; position:absolute; font-size:20; width:600px; height:80px; top:50px; left:200px;">
<input type="radio"> 0-64MB<br>
<input type="radio"> 65-256MB<br>
<input type="radio"> +257MB
</div>
</div>
</div>
<div style="border:1px solid black; position:absolute; font-size:18; width:1000px; height:160px; top:525px; left:5px;">
<div style="position:absolute; font-size:20; left:150px; top:12px;">
Message to the Tech<br>
Support:
</div>
<div style="position:absolute; left:350px; top:12px;">
<textarea rows="6" cols="70"></textarea>
</div>
</div>
<div style="border:1px solid black; position:absolute; font-size:18; width:1000px; height:70px; top:686px; left:5px;">
<div style="position:absolute; left:150px; top:10px;">
<button type=submit style="font-size:20; text-align:center;">
<img src="letter.png" width="50"; style="vertical-align:middle;> <font face="arial">Submit Your Questions</font> </button>
</div>
<div style="position:absolute; left:650px; top:10px;">
<button type=submit style="font-size:20;">
<img src="no.jpg" width="33" style="vertical-align:middle;"> <font face="arial">Reset the Form</font> </button>
</div>
</div>
<div style="Color:white; border:1px solid black; position:absolute; font-size:22; background-color:#1DDCF5; width:1000px; height:30px; top:757px; left:5px;">
<center>LanGear Inc. � 414 Wittlow Way � Farley, SD 85312 � 1 (800) 555-2377</center>
</div>
</body>
</html>