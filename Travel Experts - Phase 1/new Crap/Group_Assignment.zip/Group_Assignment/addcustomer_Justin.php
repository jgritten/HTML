<!-- Written by Chris Joo -->
<!DOCTYPE html>

<html>
<head>
<title>Untilted</title>
</head>
<body>

stuff here
<?php
	session_start();
	if ( isset($session['username']))
	{
		$id = $session['username'];
	}
	else {
	$id = 'user not logged in'; 
	}
	
	echo session_id();					// Parameter testing.  Remove for Final
	echo "<br>";
	
			$result = addCustomer($_REQUEST);
			$result2 = addCreditCard($_REQUEST);
			$result3 = addUserId($_REQUEST);

	function addCustomer($customerdata)
	{
//		$sql = "INSERT INTO customers VALUES (NULL, '$customerdata[CustFirstName]', 
//			'$customerdata[CustLastName]', '$customerdata[CustAddress]', '$customerdata[CustCity]', 
//			'$customerdata[CustProv]', '$customerdata[CustPostal]', '$customerdata[CustCountry]', 
//			'$customerdata[CustHomePhone]', '$customerdata[CustBusPhone]', 
//			'$customerdata[CustEmail]', NULL)";
//		
//
//		//print($sql);
//
//		$link = mysqli_connect("localhost", "root", "", "travelexperts") or
//				die("Error: " . mysqli_connect_error());
//		$result = mysqli_query($link, $sql) or die("Query Error: " . mysqli_error($link));
//				print("result: $result<br />");
//				mysqli_close($link);
	print('addcustomer fired');
		$link = mysqli_connect("localhost", "root", "", "travelexperts") or die("Connection Error: " . mysqli_error());
		$sql = "INSERT INTO customers VALUES (NULL, '$customerdata[CustFirstName]', 
			'$customerdata[CustLastName]', '$customerdata[CustAddress]', '$customerdata[CustCity]', 
			'$customerdata[CustProv]', '$customerdata[CustPostal]', '$customerdata[CustCountry]', 
			'$customerdata[CustHomePhone]', '$customerdata[CustBusPhone]', 
			'$customerdata[CustEmail]', NULL)";
			//(NULL, '$customerdata[CustFirstName]', '$customerdata[CustMiddleInitial]', '$customerdata[CustLastName]', '$customerdata[CustBusPhone]', '$customerdata[CustEmail]', '$customerdata[CustPosition]', $customerdata[AgencyId])";
		
		$result = mysqli_query($link,$sql) or die("SQL Error: You Dun Fukd Up, Boi");
		if ( $result )
		{
			print("Customer successfully added"."</br>");
		}
		else
		{
			print("Customer insert Failed"."</br>");
		}
		mysqli_close($link);


		return $result;
	}

	function addCreditCard($creditcard)
	{
	$dbh = mysql_connect("localhost","root","") or die("cannot connect");
	mysql_select_db("travelexperts");
	$result = mysql_query("SELECT * FROM customers ORDER BY customerid DESC LIMIT 0, 1");
		while ($row = mysql_fetch_row($result))
		{	
			$id = $row[0];
			echo $id;    	// Echos highest Customer ID. Use this for Credit Card CustomerID
		}
	
	$sql = "INSERT INTO creditcards values (NULL, '$creditcard[CCName]', '$creditcard[CCNumber]', '$creditcard[CCExpiry]', '$id')";
	$link = mysqli_connect("localhost", "root", "", "travelexperts") or
				die("Error: " . mysqli_connect_error());
	$result = mysqli_query($link,$sql) or die("SQL Error: You Dun Fukd Up, Boi");
			if ( $result )
		{
			print("Credit Card successfully added"."</br>");
		}
		else
		{
			print("Credit Card insert Failed"."</br>");
		}
			mysqli_close($link);
			mysql_close($dbh);
			return $result;

	}

	function addUserId($userid)
	{
		$sql3 = "INSERT INTO users values ('$userid[UserID]', '$userid[PW]')";
		$link3 = mysqli_connect("localhost", "root", "", "travelexperts") or
				die("Error: " . mysqli_connect_error());
		$result3 = mysqli_query($link3, $sql3) or die("Query Error: " . mysqli_error($link3));
				print("result: $result3<br />");
				mysqli_close($link3);
				return $result3;
	}

	function verifylogin($u, $p)
	{
		$link = mysqli_connect("localhost", "root", "", "travelexperts") or
				die("Error: " . mysqli_connect_error());	
		$sql = "select PW from users where UserID='$u'";
		$result = mysqli_query($link, $sql) or die("SQL Error: " . mysqli_error());
		if ($pwd = mysqli_fetch_row($result))
		{
			if ($pwd[0] == $p)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
?>
</body>
</html>
