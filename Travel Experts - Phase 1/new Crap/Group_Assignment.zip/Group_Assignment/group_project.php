<?php
date_default_timezone_set("america/edmonton");
$morning = "<b><i>Good morning!</i></b>";
$afternoon = "<b><i>Good afternoon!</i></b>";
$evening = "<b><i>Good evening!</i></b>";
$current_time = date("H");
if($current_time >= 1 && $current_time <=11)
{
print($morning);
}
elseif($current_time >= 12 && $current_time <=16)
{
print($afternoon);
}
elseif($current_time >= 17 && $current_time <=24)
{
print($evening);
}
$date = date("<b>l, F j, Y - g:i:s A</b>");
print("<br />$date");
?>
<!DOCTYPE html>
<html>
<head>
<title>Travel Experts</title> 
</head>
<style>
body {background-color:#D4DFFF; 
background-image:url(group_background.jpg); background-size:135%;}
</style>
<body>
<center>
<i><font size="12">Welcome to <u>Travel Experts</u>!</font></i>
<br>
<img src="group_picture1.jpg" height="300" width="450">
<img src="group_picture2.jpg" height="300" width="450">
<img src="group_picture3.jpg" height="300" width="450">
<br>
<br>
<b><i><font size="5">
<a href="">Vacation Packages</a>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<a href="">Customer Registration</a>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<a href="">Contact Us</a>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<a href="">User Login</a>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<a href="">Agent Login</a>
</font></i></b>
</center>
<hr>
<b>Travel Experts
<br>
Copyright &#169; 2014
<br>
All Rights Reserved</b>
</body>
</html>